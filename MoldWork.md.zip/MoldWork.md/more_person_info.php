<?php require_once "config.sql.php";
$utilizator_curent = $_GET['id'];
$query = mysqli_query($conexiune, "SELECT * FROM users WHERE id = ".$utilizator_curent);
$result = mysqli_fetch_assoc($query);?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
            integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
            integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
</head>
<body>

<div class="container" style="margin-top:13%;">

    <div class="row">
        <div class="col">
            <img src="https://www.chivmen.com/wp-content/uploads/2018/04/man-at-first-day-of-his-work.jpeg"
                 style="max-width: 500px">
        </div>
        <div class="col">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">Info:</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th scope="row">Nume</th>
                    <td><?php echo $result['name']." ".$result['family']?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <th scope="row">Localitatea</th>
                    <td><?php echo $result['localitatea']?></td>
                    <td></td>
                </tr>
                <tr>
                    <th scope="row">Specialitate</th>
                    <td><?php echo $result['specialitatea']?></td>
                    <td></td>
                </tr>
                <tr>
                    <th scope="row">Proiectele</th>
                    <td colspan="2"><?php echo $result['proiecte']?></td>
                    <td></td>
                </tr>
                <tr>
                    <th scope="row">About</th>
                    <td><?php echo $result['despre']?>
                    </td>

                    <td></td>
                </tr>
                <tr>
                </tbody>
            </table>
        </div>

    </div>
</div>
</body>
</html>
