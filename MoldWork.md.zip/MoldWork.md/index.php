<!DOCTYPE html>
<html lang="en">
<?php include "components/head.php" ?>

<body>

<header>
    <?php include "components/header.php";?>
</header>


<div class="container-fluid " id="bodyContainer">
    <section id="first-block" class="text-center ">
        <div id="mask">
            <div class="container ">
                <div class="content text-left">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="text-left h1start">
                                Make your <br> reality
                            </h1>
                            <h1 class="dreams">
                                <s>dreams</s>
                            </h1>
                            <h1 class="business">
                                business
                            </h1>
                        </div>
                        <div class="col-md-12">
                            <p id="textTop">
                                Find a job. Find a person. <br>Find a team. Form a team.
                            </p>
                        </div>
                        <div class="col-md-12">
                            <p id="textTop2">
                                <b>Grow faster.</b>
                            </p>
                        </div>
                        <div class="col-md-12" id="first-block-button">
                            <p id="buttonTop">
                                <button type="button" class="btn btn.outline"><a href="form\login.php">Sign In</a>
                                </button>
                                <button type="button" class="btn btn.outline"><a href="form\signup.php">Sign Up</a>
                                </button>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<main class="mt-5">
    <section id="second-block" class="text-center">
        <div class="container">
            <h1 class="mb-5 font-weight-bold">Popular services</h1>
            <div class="row d-flex justify-content-center mb-4">
                <div class="col-md-8">

                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-5">
                    <img src="img/im-11.png" class="img-fluid "/>
                    <h3 class="my-4 font-weight-bold">WordPress</h3>
                    <p>Best services for website costumisation.</p>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/img-31.png" class="img-fluid"/>
                    <div class="col">
                        <h3 class="my-4 font-weight-bold">Logo Design</h3>
                    </div>
                    <p>Get a beautiful designed logo for your business.</p>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/img-12.png" class="img-fluid"/>
                    <h3 class="my-4 font-weight-bold">Social Media</h3>
                    <p>Get the best services for social medias here.</p>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/img-232.png" class="img-fluid"/>
                    <h3 class="my-4 font-weight-bold">Translation</h3>
                    <p>Our professionals will translate your documents at the highest level.</p>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/img-44.png" class="img-fluid"/>
                    <h3 class="my-4 font-weight-bold">Data Entry</h3>
                    <p>Get help with typing and a lot of others data entry services.</p>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/img-22.png" class="img-fluid"/>
                    <h3 class="my-4 font-weight-bold">Illustration</h3>
                    <p>If you think you saw everything, take a look at the best illustrations you've ever seen.</p>
                </div>

                <DIV ID="toTop"> △</
                DIV ><br><br>
                <a href="#" id="scroll_bottom">▽</a>
            </div>
        </div>
    </section>

    <section id="third-block" class="text-center">
        <div class="container">
            <div class="row justify-content-center mb-4">
                <div class="col-xs-12 col-md-12 small-title text-center">

                </div>
                <div class="video col-xs-12 col-md-12 ">
                    <!--<div class="video-wrap">
                            <iframe width="1140" height="680" src="https://www.youtube.com/embed/WEDndTCyGgU" frameborder="0"
                             allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>-->
                    <div class="embed-responsive embed-responsive-21by9">
                        <iframe width="1140" height="680" src="https://www.youtube.com/embed/WEDndTCyGgU"
                                frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="fourth-block" class="text-center">
        <div class="container">
            <h1 class="mb-5 font-weight-bold">Ce cred clientii despre serviciul<br> nostru?</h1>
            <div class="row d-flex justify-content-center mb-4">
                <div class="col-md-8">

                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-5">
                    <img src="img/i-53.png" class="img-fluid"/>
                    <div class="col">
                        <p style="margin-top: 5px;">Este o platforma pe care se poate de gasit specialisti in orice
                            domeniu</p>
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/i-50.png" class="img-fluid"/>
                    <div class="col">
                        <p>Este un sait foarte util si imi ajuta sa dau proiectele la timp..</p>
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <img src="img/i-51.png" class="img-fluid"/>
                    <div class="col">
                        <p>Este o platforma care poate sa inlocuiasca lucrul de la serviciu</p>
                    </div>
                </div>
                <div class="col-md-12 mb-5 text-center">

                </div>
            </div>
        </div>
    </section>


    <section id="seven-block" class="text-center">
        <div class="container">
            <div class="col-xs-12 col-md-12 small-title text-center">
                <h4>- Ceva despre freelance -</h4>

                <div class="video1">
                    <iframe width="510" height="300" src="https://www.youtube.com/embed/KOlIXl9tUvU"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                    <iframe width="510" height="300" src="https://www.youtube.com/embed/D4e4tnO83Xg"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                </div>
            </div>

        </div>
    </section>

    <section id="eight-block" class="text-center">
        <div class="container">
            <!-- Grid row -->
            <h1 class="mb-5 font-weight-bold">Despre Moldwork</h1>
            <div class="row d-flex justify-content-center" id="card">
                <div class="col-md-10 col-sm-10 col-xl-10 py-5">
                    <div class="accordion md-accordion accordion-2 " id="accordionEx7" role="tablist"
                         aria-multiselectable="true">

                        <!-- Accordion card -->
                        <div class="card">

                            <!-- Card header -->
                            <div class="card-header rgba-stylish-strong z-depth-1 mb-1" role="tab" id="heading1">
                                <a data-toggle="collapse" data-parent="#accordionEx7" href="#collapse1"
                                   aria-expanded="true"
                                   aria-controls="collapse1">
                                    <h5 class="mb-0 white-text text-left">
                                        Ce reprezinta Moldwork?<i class="fas fa-angle-down rotate-icon"></i>
                                    </h5>
                                </a>
                            </div>

                            <!-- Card body -->
                            <div id="collapse1" class="collapse show" role="tabpanel" aria-labelledby="heading1"
                                 data-parent="#accordionEx7">
                                <div class="card-body mb-1 text-left">
                                    <p>Moldwork servește pentru a permite listarea și aplicarea pentru mici locuri de
                                        muncă unice online. Joburile listate pe platformă sunt diverse și variază de la
                                        a obține o carte de vizită bine concepută” la „ajutor cu HTML, JavaScript, CSS
                                        și jQuery”.Moldwork este o companie construită pe modelul listării posturilor de
                                        muncă temporară. Freelancerii lucrează într-o varietate de locuri de muncă, de
                                        la acasă la birou.Moldwork servește ca platformă de comerț electronic pentru
                                        freelanceri și companii pentru a-și vinde serviciile folosind saitul nostru.</p>


                                </div>
                            </div>
                        </div>
                        <!-- Accordion card -->

                        <!-- Accordion card -->
                        <div
                        <!-- Card body -->
                        <div id="collapse3" class="collapse" role="tabpanel" aria-labelledby="heading3"
                             data-parent="#accordionEx7">

                        </div>
                    </div>
                    <!-- Accordion card -->
                </div>
            </div>
        </div>
    </section>


    <section id="eleven-block" class="text-center">
        <div class="container">
            <div class="col-xs-12 col-md-12 small-title text-center">
                <h4>Partenerii nostri de incredere</h4>
            </div>
            <div class="col-md-12 col-xs-12" id="imgBlock">
                <div class="row">
                    <div class="col-md col-sm-6 col-xs-6 text-center brend odd">
                        <a href="https://www.google.ru/"> <img src="img/google.png" class="img-fluid">
                    </div>
                    <div class="col-md col-sm-6 col-xs-6 text-center brend even">
                        <a href="https://www.yandex.ru"> <img src="img/yandex.png" class="img-fluid">
                    </div>
                    <div class="col-md col-sm-6 col-xs-6 text-center brend odd">
                        <a href="https://www.oracle.com"> <img src="img/oracle1.png" class="img-fluid">
                    </div>
                    <div class="col-md col-sm-6 col-xs-6 text-center brend even">
                        <a href="https://www.microsoft.com"> <img src="img/microsoft.png" class="img-fluid">
                    </div>
                    <div class="col-md col-sm-6 col-xs-6 text-center brend last">
                        <a href="https://www.amazon.com"> <img src="img/amazon.png" class="img-fluid">
                    </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section id="twelve-block" class="text-center">
        <div class="container">
            <div class="col-xs-12 col-md-12 small-title text-center">
                <h2>-- URMEAZĂ-NE PE RETELE DE SOCIALIZARE- -</h2>
                <br>
                <br>
                <br>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                    <a href="https://www.facebook.com/"><img src="img/post9.png" class="img-fluid"></a>
                    <h2>FACEBOOK</h2>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                    <a href="https://twitter.com/"><img src="img/post8.png" class="img-fluid"></a>
                    <h2>TWITTER</h2>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                    <a href="https://www.instagram.com/"><img src="img/img-11.png" class="img-fluid"></a>
                    <h2>INSTAGRAM</h2>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                    <a href="https://www.vk.com/"><img src="img/post-10.png" class="img-fluid"></a>
                    <h2>VK</h2>
                </div>

            </div>
        </div>
    </section>

    <section id="thirteen-block" class="text-center">
        <div class="container" id="first-footer-container">
            <div class="row d-flex justify-content-center mb-4">
                <div class="col-md-12">
                    <h1 class="mb-5 font-weight-bold text-center">Este foarte usor <br>si comod!</h1>
                </div>
                <div class="col-md-12">
                    <p class="text-center"><small>Abonați-vă la newsletter</small></p>
                </div>
                <div class="col-md-3 col-sm-2"></div>
                <div class="col-md-6 col-sm-8">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Adresa ta de email"
                               aria-label="adresa ta de email" aria-describedby="button-addon1" id="searchInput1">
                        <div class="input-group-append">
                            <button class="btn btn-md  m-0 px-3 py-2 z-depth-0 " type="button"
                                    id="button-addon1">A te alatura
                            </button>

                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-2"></div>
            </div>
        </div>


        <div class="content">
        </div>
        <footer id="myFooter">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 myCols">
                        <h5>Sa incepem</h5>
                        <ul>
                            <li><a href="index.php">Acasa</a></li>
                            <li><a href="form/signup.php">Inregistrare</a></li>
                            <li><a href="#">Descarca</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3 myCols">
                        <h5>Despre noi</h5>
                        <ul>
                            <li><a href="#">Despre sait</a></li>

                            <li><a href="#">Vizualizari</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3 myCols">
                        <h5>Contactati-ne</h5>
                        <ul>
                            <li><a href="contact.html">Contacte</a></li>
                            <li><a href="feedback.html">Feedback</a></li>
                        </ul>
                    </div>
                    <a href="https://play.google.com/store"><img class="google" src="img\playgoogle.png">
                        <a href="https://www.apple.com/ru/app-store/"><img class="apple" src="img\applestore.png">

                </div>
            </div>
            <div class="social-networks">
                <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                <a href="borjak" class="facebook"><i class="fa fa-facebook-official"></i></a>
                <a href="#" class="google"><i class="fa fa-google-plus"></i></a>
            </div>
            <div class="footer-copyright">
                <p>© Moldwork 2021</p>
            </div>
        </footer>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>

</html>
