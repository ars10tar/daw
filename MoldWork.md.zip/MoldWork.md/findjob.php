
<body background="img/13.png">
<link rel="stylesheet" type="text/css" href="assets/pacient.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dekko&display=swap" rel="stylesheet">


<?php

require_once('config.sql.php');


$cerereSQL = "SELECT name,data_n,an_inscriere,email,telefon,mobil,comentariu FROM job2021";
$rezultat = mysqli_query($conexiune, $cerereSQL);

if (!$rezultat) {
    die ("EROARE: nu pot executa interogarea $cerereSQL" . "<br/>" . mysqli_error($conexiune));
} else {
    echo "
<html>
<head>
<link rel=\"stylesheet\" href=\"../style.css\" type=\"text/css\" />
</head>
<body style=\"padding: 30px;\">
<h3 class=pacient>Joburi</h3>
<table class=\"pacienti\" border=\"0\" width=\"100%\">
<tr style=\"background-color: #2F4F4F; color: #ffffff;\"><td>Nume_Job</td><td>Data_Publicarii</td><td>Experienta</td><td>E-mail</td>
<td>Telefon_Fix</td><td>Mobil</td><td>Descriere</td></tr>";


    while ($rand = mysqli_fetch_array($rezultat)) {

        echo '<tr><td>' . $rand['name'] . ' ' . $rand['prenume'] . '</td>
<td>' . $rand['data_n'] . '</td>
<td>' . $rand['an_inscriere'] . '</td>
<td>' . $rand['email'] . '</td>
<td>' . $rand['telefon'] . '</td>
<td>' . $rand['mobil'] . '</td>
<td>' . $rand['comentariu'] . '</td></tr>';
    }
    echo "</TABLE>";
}

mysqli_close($conexiune);
?>
<table border="0" width="1100" height="90" align="center">
    <tr>

        </td>
    </tr>
</table>
