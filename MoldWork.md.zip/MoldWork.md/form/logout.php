<?php 
require __DIR__ . '/header.php'; // conectam header

require "db.php"; // conectam cu failu bd

// Se face iesirea utilizatorului
unset($_SESSION['logged_user']);

// redectioneaza la inceputu paginii
header('Location: ../index.php');

require __DIR__ . '/footer.php'; // conectam footer
?>