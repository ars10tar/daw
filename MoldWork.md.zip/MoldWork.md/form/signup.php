<?php
$title = "Inregistrarea"; // denumirea formei
require __DIR__ . '/header.php'; // conectam header
require "db.php"; // conectam failu pentru conectarea cu bd

// Cream o variabilă pentru a colecta date de la utilizator folosind metoda POST
$data = $_POST;

// Utilizatorul face clic pe butonul „Înregistrare” și codul începe să se execute
if (isset($data['do_signup'])) {

    // Ne înregistrăm
    // Cream o matrice pentru a colecta erori
    $errors = array();

    // Efectuam verificări
    // trim - elimină spații (sau alte caractere) de la începutul și sfârșitul șirului
    if (trim($data['login']) == '') {

        $errors[] = "introduceti login!";
    }

    if (trim($data['email']) == '') {

        $errors[] = "introdu Email";
    }


    if (trim($data['name']) == '') {

        $errors[] = "Introduce prenumele";
    }

    if (trim($data['family']) == '') {

        $errors[] = "introdu numele";
    }

    if ($data['password'] == '') {

        $errors[] = "Introdu parola";
    }

    if ($data['password_2'] != $data['password']) {

        $errors[] = "Parola repetată a fost introdusă incorect!";
    }
    // funcția mb_strlen - obține lungimea șirului
    // Dacă autentificarea are mai puțin de 5 caractere și mai mult de 90, atunci va fi emisă o eroare
    if (mb_strlen($data['login']) < 5 || mb_strlen($data['login']) > 90) {

        $errors[] = "Lungime de conectare nevalidă";

    }

    if (mb_strlen($data['name']) < 3 || mb_strlen($data['name']) > 50) {

        $errors[] = "Lungimea numelui nevalidă";

    }

    if (mb_strlen($data['family']) < 5 || mb_strlen($data['family']) > 50) {

        $errors[] = "Lungimea numelui de familie este nevalidă";

    }

    if (mb_strlen($data['password']) < 2 || mb_strlen($data['password']) > 8) {

        $errors[] = "Lungimea parolei este nevalidă (de la 2 la 8 caractere)";

    }

    // vefirica daca e corect scris Email
    if (!preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $data['email'])) {

        $errors[] = 'E-mail introdus incorect';

    }

    // Verificarea unicității loginului
    if (R::count('users', "login = ?", array($data['login'])) > 0) {

        $errors[] = "Utilizator cu această autentificare există!";
    }

    // Verificarea unicității email

    if (R::count('users', "email = ?", array($data['email'])) > 0) {

        $errors[] = "Utilizator cu acest e-mail există!";
    }


    if (empty($errors)) {

        // Totul este verificat, înregistrează-te
// Cream tabelul utilizatorilor
        $user = R::dispense('users');

        // adaugă înregistrări la tabel
        $user->login = $data['login'];
        $user->email = $data['email'];
        $user->name = $data['name'];
        $user->family = $data['family'];

        // Hashuram parola
        $user->password = password_hash($data['password'], PASSWORD_DEFAULT);

        // Salvam tabelul
        R::store($user);
        echo '<div style="color: green; ">Sunteți înregistrat cu succes! Se poate va sa <a href="login.php">autorizati</a>.</div><hr>';

    } else {
        // array_shift () preia prima valoare a matricei și o returnează, micșorând dimensiunea matricei cu un element.
        echo '<div style="color: red; ">' . array_shift($errors) . '</div><hr>';
    }
}
?>
<head>
    <link href="css/forma.css" rel="stylesheet">
</head>


<div class="container mt-4">
    <a class="navbar-brand" href="../index.php"><img src="img/logo14.png" class="imgLogo img-fluid"/></a>

    <div class="row">
        <div class="col">
            <br><br><br>
            <!-- Forma de inregistrare -->

            <div align="right">
                <img src="\img\img-01.png" width="230" height="210" alt="absolute"><br><br><br></div>
            <form action="signup.php" method="post">
                <input type="text" class="form-control" name="login" id="login" placeholder="introdu login"><br>
                <input type="email" class="form-control" name="email" id="email" placeholder="introdu Email"><br>
                <input type="text" class="form-control" name="name" id="name" placeholder="introdu prenume"
                       required><br>
                <input type="text" class="form-control" name="family" id="family" placeholder="introdu nume"
                       required><br>
                <input type="password" class="form-control" name="password" id="password"
                       placeholder="introdu parola"><br>
                <input type="password" class="form-control" name="password_2" id="password_2"
                       placeholder="introdu parola repetat"><br>
                <button class="btn btn-success" name="do_signup" type="submit">Inregistrare</button>
            </form>
            <br>
            <p>Dacă sunteți înregistrat, faceți click <a href="login.php">aici</a>.</p>
            <p>Inapoi <a href="./index.php">Acasa</a>.</p></div>
    </div>
</div>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>><br><br><br><br><br><br>
<br><br>
<?php require __DIR__ . '/footer.php'; ?> <! - Conectam subsolul proiectului ->
