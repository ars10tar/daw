<?php 
$title="Forma de autorizare"; // numele formularului
require __DIR__ . '/header.php'; // conectam antetul proiectului
require "db.php"; // include fișierul pentru a se conecta la baza de date
// Cream o variabilă pentru a colecta date de la utilizator folosind metoda POST
$data = $_POST;

// Utilizatorul face clic pe butonul „Log in” și codul începe să se execute
if(isset($data['do_login'])) { 

 // Cream o matrice pentru a colecta erori
 $errors = array();

 // Căutam utilizatori în tabelusers
 $user = R::findOne('users', 'login = ?', array($data['login']));

 if($user) {

 	// Dacă autentificarea există, atunci verificam parola
 	if(password_verify($data['password'], $user->password)) {

 		// Așa este, ii dam voi utilizatorului sa conecteze
 		$_SESSION['logged_user'] = $user;
 		
 		// Redirecționează către pagina principală
                header('Location: index.php');

 	} else {
    
    $errors[] = 'Parola introdusă incorect!';

 	}

 } else {
 	$errors[] = 'Utilizatorul cu acest nume de utilizator nu a fost găsit!';
 }

if(!empty($errors)) {

		echo '<div style="color: red; ">' . array_shift($errors). '</div><hr>';

	}

}
?>

    
    <head>
    	 <link href="css/forma.css" rel="stylesheet">
    	 <link href="css\text.css" rel="stylesheet">
    	 <link href="css/text.css" rel="stylesheet">
    	  <link href="css\border.css" rel="stylesheet">
    	 <link href="css/border.css" rel="stylesheet">
    	  <link href="css\border.css" rel="stylesheet">
    	</head>

    
<div class="container mt-4">
	 <a class="navbar-brand" href="../index.php"><img src="img/logo14.png"  class="imgLogo img-fluid" /></a>

		<div class="row">
			<div class="col">
				<br><br><br><br>
				
		<!-- Forma de autorizare -->
		
		<div align="right">
		<img  src="\img\img-01.png" width="230" height="210"alt="absolute"><br><br><br></div>
		<form action="login.php" method="post">
			<input type="text" class="form-control" name="login" id="login" placeholder="introdu login" required><br>
			<input type="password" class="form-control" name="password" id="pass" placeholder="introdu parola" required><br>
			<button class="btn btn-success" name="do_login" type="submit">Autorizare</button>
		</form>
		<br>
		<p>Dacă nu sunteți încă înregistrat, faceți click <a href="signup.php">aici</a>.</p>
		<p>Inapoi <a href="../index.php">Acasa</a>.</p>
			</div>
		</div>
	</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php require __DIR__ . '/footer.php'; ?> <!--Conectam subsolul proiectului ->