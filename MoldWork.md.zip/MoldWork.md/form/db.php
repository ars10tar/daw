<?php
// Conectam biblioteca RedBeanPHP
require "libs/rb-mysql.php";

// ne conectam cu bd
R::setup( 'mysql:host=localhost;dbname=moldwork',
        'root', '' );

// verificarea conectarii cu bd
if(!R::testConnection()) die('No DB connection!');

session_start(); // Cream o sesiune pentru autorizare
?>