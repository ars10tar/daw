<!DOCTYPE html>
<html>

<head>
    <title>Subsolul</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Footer-with-social-icons.css">

</head>

<body>
<div class="content">
</div>
    <footer id="myFooter">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 myCols">
                    <h5>Sa incepem</h5>
                    <ul>
                        <li><a href="index.php">Acasa</a></li>
                        <li><a href="form/signup.php">Inregistrare</a></li>
                        <li><a href="#">Descarca</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 myCols">
                    <h5>Despre noi</h5>
                    <ul>
                        <li><a href="#">Despre sait</a></li>
                        <li><a href="contact.html">Contactati-ne</a></li>
                        <li><a href="#">Vizualizari</a></li>
                    </ul>
                </div>
                <div class="col-sm-3 myCols">
                    <h5>Support</h5>
                    <ul>
                        <li><a href="#"></a></li>
                        <li><a href="#"></a></li>
                        <li><a href="#"></a></li>
                    </ul>
                </div>
               
        <div class="col-sm-3 myCols">
                    <h5>Contactati-ne</h5>
                    <ul>
                            <li><a href="../contact.html">Contacte</a></li>
                        <li><a href="../feedback.html">Feedback</a></li>
                    </ul>
                </div>
        <div class="social-networks">
            <a href="www.facebook.com" class="twitter"><i class="fa fa-twitter"></i></a>
            <a href="borjak" class="facebook"><i class="fa fa-facebook-official"></i></a>
            <a href="#" class="google"><i class="fa fa-google-plus"></i></a>
        </div>
        <div class="footer-copyright">
               <p>© Moldwork 2021</p>
        </div>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>

</html>
