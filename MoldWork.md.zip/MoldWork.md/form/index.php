<?php
$title = "Moldwork"; // Denumirea formei
require __DIR__ . '/header.php'; // conectați antetul proiectului(sapca)
require "db.php"; // conectam fișierul pentru a ne conecta la baza de date
?>
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="css/photo.css">
<div class="container mt-4">
    <div class="row">
        <div class="col">
        </div>
    </div>
</div>
<div style="color=green">
    <img align="left" src="img/avatar.png"
         width="50" height="50">

    <! - Dacă suntem autentificat, va afișa un salut ->
    <?php if (isset($_SESSION['logged_user'])) : ?>
    Salut, <?php echo $_SESSION['logged_user']->name; ?></br>

    <! - Utilizatorul poate face clic pe deconectare pentru a se deconecta ->
    <a href="logout.php">Iesire</a> <!-- fișier logout.php creați mai jos -->

</div>

<?php else : ?>

    <! - Dacă utilizatorul nu este autorizat, va afișa linkuri către autorizare și înregistrare ->
    <a href="login.php">Autorizare</a><br>
    <a href="signup.php">Inregistrare</a>
<?php endif; ?>
<div>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/Footer-with-social-icons.css">
        <title>MoldWork</title>
        <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <!-- Bootstrap core CSS -->
        <link href="css/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="css/css/mdb.min.css" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <link href="css/css/style.css" rel="stylesheet">
        <link href="assets/css/cnopca.css" rel="stylesheet">
        <link href="assets/css/bottom.css" rel="stylesheet">
        <link href="assets/css\bottom.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="assets\cnopca.css">
        <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">


        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

        <script type="text/javascript">
            <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

        <script type="text/javascript">

            $(function () {
                $(window).scroll(function () {
                    if ($(this).scrollTop() != 0) {
                        $('#toTop').fadeIn();
                    } else {
                        $('#toTop').fadeOut();
                    }
                });
                $('#toTop').click(function () {

                    $('body,html').animate({scrollTop: 0}, 800);
                });
            });
        </script>
        <script type="text/javascript">
            $(function () {
                $('#scroll_bottom').click(function () {
                    $('html, body').animate({scrollTop: $(document).height() - $(window).height()}, 600);
                    return false;
                });
            });
        </script>
    </head>

    <body>

    <header>
        <nav class="mb-1 navbar  navbar-expand-lg navbar-dark grey">
            <div class="container">
                <a class="navbar-brand" href="index.php"><img src="img/logo112.png" class="imgLogo img-fluid"/></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4"
                        aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <div id="hamburger" class="svg-icon" pt-1>
                            <!--?xml version="1.0" encoding="UTF-8"?-->
                            <svg width="30px" height="18px" viewBox="0 0 30 18" version="1.1"
                                 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

                                <title>Moldwork</title>

                                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="menu">
                                        <rect id="Rectangle" fill="transparent" fill-rule="nonzero" x="0" y="0"
                                              width="30" height="18"></rect>
                                        <g id="Group-4" transform="translate(2.000000, 5.000000)" fill="#2E2E2E">
                                            <rect id="Rectangle" x="0" y="0" width="24" height="2"></rect>
                                            <rect id="Rectangle" x="10" y="5" width="14" height="2"></rect>
                                        </g>
                                    </g>
                                </g>
                            </svg>
                        </div>
                    </span>
                    <span id="mobileMenu">Menu</span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent-4">
                    <ul class="navbar-nav  ml-auto">
                        <li class="nav-item pl-5">
                            <a class="nav-link" href="../findjob.php">
                                Find Job
                            </a>
                        </li>
                        <li class="nav-item pl-5">
                            <a class="nav-link" href="../findPerson.php">
                                Find Person
                            </a>
                        </li>
                        <li class="nav-item pl-5">
                            <a class="nav-link" href="../findTeam.php">
                                Find Team
                            </a>
                        </li>
                        <li class="nav-item pl-5">
                            <a class="nav-link" href="../formTeam.php">
                                Form Team
                            </a>
                        </li>
                    </ul>
                    <!--<ul class="navbar-nav ml-auto">
                        <li class="nav-item ">
                            <button type="button" class="btn buttonMenu"> <a href="">Kauppa</a></button>
                        </li>
                    </ul>-->
                </div>
            </div>
        </nav>
    </header>


    <div class="container-fluid " id="bodyContainer">
        <section id="first-block" class="text-center ">
            <div id="mask">
                <div class="container ">
                    <div class="content text-left">
                        <div class="row">
                            <div class="col-md-12">
                                <h1 class="text-left h1start">
                                    Make your <br> reality
                                </h1>
                                <h1 class="dreams">
                                    <s>dreams</s>
                                </h1>
                                <h1 class="business">
                                    business
                                </h1>
                            </div>
                            <div class="col-md-12">
                                <p id="textTop">
                                    Find a job. Find a person. <br>Find a team. Form a team.
                                </p>
                            </div>
                            <div class="col-md-12">
                                <p id="textTop2">
                                    <b>Grow faster.</b>
                                </p>
                            </div>
                            <div class="col-md-12" id="first-block-button">
                                <p id="buttonTop">

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <main class="mt-5">
        <section id="second-block" class="text-center">
            <div class="container">
                <h1 class="mb-5 font-weight-bold">Popular services</h1>
                <div class="row d-flex justify-content-center mb-4">
                    <div class="col-md-8">

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <img src="img/im-11.png" class="img-fluid "/>
                        <h3 class="my-4 font-weight-bold">WordPress</h3>
                        <p>Best services for website costumisation.</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/img-31.png" class="img-fluid"/>
                        <div class="col">
                            <h3 class="my-4 font-weight-bold">Logo Design</h3>
                        </div>
                        <p>Get a beautiful designed logo for your business.</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/img-12.png" class="img-fluid"/>
                        <h3 class="my-4 font-weight-bold">Social Media</h3>
                        <p>Get the best services for social medias here.</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/img-232.png" class="img-fluid"/>
                        <h3 class="my-4 font-weight-bold">Translation</h3>
                        <p>Our professionals will translate your documents at the highest level.</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/img-44.png" class="img-fluid"/>
                        <h3 class="my-4 font-weight-bold">Data Entry</h3>
                        <p>Get help with typing and a lot of others data entry services.</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/img-22.png" class="img-fluid"/>
                        <h3 class="my-4 font-weight-bold">Illustration</h3>
                        <p>If you think you saw everything, take a look at the best illustrations you've ever seen.</p>
                    </div>

                    <DIV ID="toTop"> △</
                    DIV ><br><br>
                    <a href="#" id="scroll_bottom">▽</a>
                </div>
            </div>
        </section>

        <section id="third-block" class="text-center">
            <div class="container">
                <div class="row justify-content-center mb-4">
                    <div class="col-xs-12 col-md-12 small-title text-center">

                    </div>
                    <div class="video col-xs-12 col-md-12 ">
                        <!--<div class="video-wrap">
                                <iframe width="1140" height="680" src="https://www.youtube.com/embed/WEDndTCyGgU" frameborder="0"
                                 allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>-->
                        <div class="embed-responsive embed-responsive-21by9">
                            <iframe width="1140" height="680" src="https://www.youtube.com/embed/WEDndTCyGgU"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="fourth-block" class="text-center">
            <div class="container">
                <h1 class="mb-5 font-weight-bold">Ce cred clientii despre serviciul<br> nostru?</h1>
                <div class="row d-flex justify-content-center mb-4">
                    <div class="col-md-8">

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <img src="img/i-53.png" class="img-fluid"/>
                        <p>Este o platforma pe care se poate de gasit specialisti in orice domeniu</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/i-50.png" class="img-fluid"/>
                        <p>Este un sait foarte util si imi ajuta sa dau proiectele la timp..</p>
                    </div>
                    <div class="col-md-4 mb-5">
                        <img src="img/i-51.png" class="img-fluid"/>
                        <p>Este o platforma care poate sa inlocuiasca lucrul de la serviciu</p>
                    </div>
                    <div class="col-md-12 mb-5 text-center">

                    </div>
                </div>
            </div>
        </section>

        <section id="fifth-block" class="text-center">
            <img src="img/bg-img-1.png" class="img-fluid">
        </section>


</div>
<section id="seven-block" class="text-center">
    <div class="container">
        <div class="col-xs-12 col-md-12 small-title text-center">
            <h4>- Ceva despre freelance -</h4>
        </div>
        <div class="row">
            <div class="col-md-4 mb-5">
                <center>
                    <div style align="center">

                        <iframe width="560" height="315" src="https://www.youtube.com/embed/KOlIXl9tUvU"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>

                    </div>
            </div>

        </div>
    </div>
</section>

<section id="eight-block" class="text-center">
    <div class="container">
        <!-- Grid row -->
        <h1 class="mb-5 font-weight-bold">Despre Moldwork</h1>
        <div class="row d-flex justify-content-center" id="card">
            <div class="col-md-10 col-sm-10 col-xl-10 py-5">
                <div class="accordion md-accordion accordion-2 " id="accordionEx7" role="tablist"
                     aria-multiselectable="true">

                    <!-- Accordion card -->
                    <div class="card">

                        <!-- Card header -->
                        <div class="card-header rgba-stylish-strong z-depth-1 mb-1" role="tab" id="heading1">
                            <a data-toggle="collapse" data-parent="#accordionEx7" href="#collapse1" aria-expanded="true"
                               aria-controls="collapse1">
                                <h5 class="mb-0 white-text text-left">
                                    Ce reprezinta Moldwork?<i class="fas fa-angle-down rotate-icon"></i>
                                </h5>
                            </a>
                        </div>

                        <!-- Card body -->
                        <div id="collapse1" class="collapse show" role="tabpanel" aria-labelledby="heading1"
                             data-parent="#accordionEx7">
                            <div class="card-body mb-1 text-left">
                                <p>Moldwork servește pentru a permite listarea și aplicarea pentru mici locuri de muncă
                                    unice online. Joburile listate pe platformă sunt diverse și variază de la a obține o
                                    carte de vizită bine concepută” la „ajutor cu HTML, JavaScript, CSS și
                                    jQuery”.Moldwork este o companie construită pe modelul listării posturilor de muncă
                                    temporară. Freelancerii lucrează într-o varietate de locuri de muncă, de la acasă la
                                    birou.Moldwork servește ca platformă de comerț electronic pentru freelanceri și
                                    companii pentru a-și vinde serviciile folosind saitul nostru.</p>


                            </div>
                        </div>
                    </div>
                    <!-- Accordion card -->

                    <!-- Accordion card -->
                    <div
                    <!-- Card body -->
                    <div id="collapse3" class="collapse" role="tabpanel" aria-labelledby="heading3"
                         data-parent="#accordionEx7">

                    </div>
                </div>
                <!-- Accordion card -->
            </div>
        </div>
    </div>
</section>


<section id="eleven-block" class="text-center">
    <div class="container">
        <div class="col-xs-12 col-md-12 small-title text-center">
            <h4>Partenerii nostri de incredere</h4>
        </div>
        <div class="col-md-12 col-xs-12" id="imgBlock">
            <div class="row">
                <div class="col-md col-sm-6 col-xs-6 text-center brend odd">
                    <img src="img/google.png" class="img-fluid">
                </div>
                <div class="col-md col-sm-6 col-xs-6 text-center brend even">
                    <img src="img/yandex.png" class="img-fluid">
                </div>
                <div class="col-md col-sm-6 col-xs-6 text-center brend odd">
                    <img src="img/oracle1.png" class="img-fluid">
                </div>
                <div class="col-md col-sm-6 col-xs-6 text-center brend even">
                    <img src="img/microsoft.png" class="img-fluid">
                </div>
                <div class="col-md col-sm-6 col-xs-6 text-center brend last">
                    <img src="img/amazon.png" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</section>
<section id="twelve-block" class="text-center">
    <div class="container">
        <div class="col-xs-12 col-md-12 small-title text-center">
            <h2>-- URMEAZĂ-NE PE RETELE DE SOCIALIZARE- -</h2>
            <br>
            <br>
            <br>
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                <a href="https://www.facebook.com/"><img src="img/post9.png" class="img-fluid"></a>
                <h2>FACEBOOK</h2>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                <a href="https://twitter.com/"><img src="img/post8.png" class="img-fluid"></a>
                <h2>TWITTER</h2>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                <a href="https://www.instagram.com/"><img src="img/img-11.png" class="img-fluid"></a>
                <h2>INSTAGRAM</h2>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 text-center post">

                <a href="https://www.vk.com/"><img src="img/post-10.png" class="img-fluid"></a>
                <h2>VK</h2>
            </div>

        </div>
    </div>
</section>

<section id="thirteen-block" class="text-center">
    <div class="container" id="first-footer-container">
        <div class="row d-flex justify-content-center mb-4">
            <div class="col-md-12">
                <h1 class="mb-5 font-weight-bold text-center">Este foarte usor <br>si comod!</h1>
            </div>
            <div class="col-md-12">
                <p class="text-center"><small>Abonați-vă la newsletter</small></p>
            </div>
            <div class="col-md-3 col-sm-2"></div>
            <div class="col-md-6 col-sm-8">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Adresa ta de email"
                           aria-label="adresa ta de email" aria-describedby="button-addon1" id="searchInput1">
                    <div class="input-group-append">
                        <button class="btn btn-md  m-0 px-3 py-2 z-depth-0 " type="button"
                                id="button-addon1">A te alatura
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-2"></div>
        </div>
    </div>


    </section>

    </html>

    <?php require __DIR__ . '/footer.php'; ?> <!--
Conectam subsolul proiectului ->