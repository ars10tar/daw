<?php
Error_Reporting(E_ALL & ~E_NOTICE);

$AdresaBazaDate = "localhost";
$UtilizatorBazaDate = "root";
$ParolaBazaDate = "";
$NumeBazaDate = "moldwork";
$conexiune = mysqli_connect($AdresaBazaDate, $UtilizatorBazaDate, $ParolaBazaDate, $NumeBazaDate);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

if (function_exists('date_default_timezone_set'))
    date_default_timezone_set('Europe/chisinau');
function addentities($data)
{
    if (trim($data) != '') {
        $data = htmlentities($data, ENT_QUOTES);
        return str_replace('\\', '&#92;', $data);
    } else
        return $data;
} 

