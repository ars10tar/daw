<!DOCTYPE html>
<?php include_once "config.sql.php" ?>
<html lang="en" style="overflow-x: hidden;">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Footer-with-social-icons.css">
    <title>MoldWork</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">
    <title>Find Person</title>
    <link rel="stylesheet" href="css/css.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
            integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
            integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>

</head>
<body>
<header>
    <?php include "components/header.php";?>
</header>


<div class="row">
    <div class="col-12 col-md-10">
        <table class="table">
            <thead style="margin-left: 5px;">
            <tr>
                <th scope="col"><h3><b>Team name</b></h3></th>
                <th scope="col"><h3><b>Number of peoples</b></h3></th>
                <th scope="col"><h3><b>Domain</b></h3></th>
            </tr>
            </thead>
            <tbody style="margin-left: 5px;">
            <?php if (isset($_POST['filtreaza'])) {
                if (!is_null($_POST['filter'])) {
                    foreach ($_POST['filter'] as $iterator) {
                        if (!is_null($second_array))
                            $second_array .= " or team_data.domain_id =" . $iterator;
                        else
                            $second_array .= $iterator;
                    }
                }
                $query = mysqli_query($conexiune, "SELECT * FROM team_data INNER JOIN domains ON team_data.domain_id = domains.id WHERE team_data.domain_id =" . $second_array);
                //echo "SELECT * FROM team_data INNER JOIN domains ON team_data.domain_id = domains.id WHERE team_data.domain_id =".$second_array;
                while ($result = mysqli_fetch_assoc($query)) {
                    ?>
                    <tr>
                        <td><h4><?php echo $result['team_name'] ?></h4></td>
                        <td><h4><?php echo $result['person_number'] ?></h4></td>
                        <td><h4><?php echo $result['domain_name'] ?></h4></td>

                    </tr>
                <?php }
            } else {
                $query = mysqli_query($conexiune, "SELECT * FROM team_data INNER JOIN domains ON team_data.domain_id = domains.id");
                while ($result = mysqli_fetch_assoc($query)) { ?>
                    <tr>
                        <td><h4><?php echo $result['team_name'] ?></h4></td>
                        <td><h4><?php echo $result['person_number'] ?></h4></td>
                        <td><h4><?php echo $result['domain_name'] ?></h4></td>

                    </tr>
                <?php }
            } ?>
            </tbody>
        </table>
    </div>
    <div class="col-6 col-md-2" style="margin-right: -5px;"><h3 aligne="center"><b>Filters</b></h3>

        <form method="post">
            <h4>Domains</h4>
            <div>
                <?php $query_filter = mysqli_query($conexiune, "SELECT * FROM domains");
                while ($result = mysqli_fetch_assoc($query_filter)) {
                    ?>
                    <label>
                        <input type="checkbox" name="filter[]" value="<?php echo $result['id'] ?>">
                        <span><?php echo $result['domain_name'] ?></span>
                    </label>
                <?php } ?>
            </div>
            <input class="btn btn-success" type="submit" name="filtreaza" value="Show">
            <a href="findTeam.php"><input class="btn btn-success" type="button" value="Reset"></a>
        </form>

    </div>
</div>


</body>
<div class="content">
</div>
<?php require_once "components/footer.php"?>
</html>
