$(window).scroll(function() {
    var height = $(window).scrollTop();
     /*Если сделали скролл на 100px задаём новый класс для header*/
    if(height > 1){
    $('nav').addClass('fixed-top');
    $('.buttonMenu').css({
        'border':'none',
        'background-color':'#3399ff'
    })
    } else{
    /*Если меньше 100px удаляем класс для header*/
    $('nav').removeClass('fixed-top');
    $('.buttonMenu').css({
        'border':'2px solid #000',
        'background-color':'transparent'
    })
    }
});