<footer id="myFooter">
    <div class="container">
        <div class="row">
            <div class="col-sm-3 myCols">
                <h5>Sa incepem</h5>
                <ul>
                    <li><a href="index.php">Acasa</a></li>
                    <li><a href="form/signup.php">Inregistrare</a></li>
                    <li><a href="#">Descarca</a></li>
                </ul>
            </div>
            <div class="col-sm-3 myCols">
                <h5>Despre noi</h5>
                <ul>
                    <li><a href="#">Despre sait</a></li>

                    <li><a href="#">Vizualizari</a></li>
                </ul>
            </div>
            <div class="col-sm-3 myCols">
                <h5>Contactati-ne</h5>
                <ul>
                    <li><a href="contact.html">Contacte</a></li>
                    <li><a href="feedback.html">Feedback</a></li>
                </ul>
            </div>
            <a href="https://play.google.com/store"><img class="google" src="img\playgoogle.png">
                <a href="https://www.apple.com/ru/app-store/"><img class="apple" src="img\applestore.png">

        </div>
    </div>
    <div class="social-networks">
        <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
        <a href="borjak" class="facebook"><i class="fa fa-facebook-official"></i></a>
        <a href="#" class="google"><i class="fa fa-google-plus"></i></a>
    </div>
    <div class="footer-copyright">
        <p>© Moldwork 2021</p>
    </div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>