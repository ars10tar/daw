<nav class="mb-1 navbar  navbar-expand-lg navbar-dark grey">
    <div class="container">
        <a class="navbar-brand" href="index.php"><img src="img/logo112.png" class="imgLogo img-fluid" /></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4"
                aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon">
                      <div id="hamburger" class="svg-icon" pt-1>
                          <!--?xml version="1.0" encoding="UTF-8"?-->
                          <svg width="30px" height="18px" viewBox="0 0 30 18" version="1.1"
                               xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

                              <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                  <g id="menu">
                                      <rect id="Rectangle" fill="transparent" fill-rule="nonzero" x="0" y="0"
                                            width="30" height="18"></rect>
                                      <g id="Group-4" transform="translate(2.000000, 5.000000)" fill="#2E2E2E">
                                          <rect id="Rectangle" x="0" y="0" width="24" height="2"></rect>
                                          <rect id="Rectangle" x="10" y="5" width="14" height="2"></rect>
                                      </g>
                                  </g>
                              </g>
                          </svg>
                      </div>
                  </span>
            <span id="mobileMenu">Menu</span>
        </button>
        <div class="collapse navbar-collapse " id="navbarSupportedContent-4">
            <ul class="navbar-nav  ml-auto">
                <li class="nav-item pl-5">
                    <a class="nav-link"  href="findjob.php">
                        Find Job
                    </a>
                </li>
                <li class="nav-item pl-5">
                    <a class="nav-link" href="findPerson.php">
                        Find Person
                    </a>
                </li>
                <li class="nav-item pl-5">
                    <a class="nav-link" href="findTeam.php">
                        Find Team
                    </a>
                </li>
                <li class="nav-item pl-5">
                    <a class="nav-link" href="formTeam.php">
                        Form Team
                    </a>
                </li>
            </ul>

            <ol>
                <li class="nav-item pl-5">
                    <a class="nav-link" href="form\login.php">
                        Sign In
                    </a>
                </li>
                <li class="nav-item pl-5">
                    <a class="nav-link" href="form\signup.php">
                        Sign Up
                    </a>
                </li>
            </ol>
        </div>
    </div>
</nav>