<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Footer-with-social-icons.css">
    <title>MoldWork</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">
    <link href="assets/cnopca.css" rel="stylesheet">
    <link href="assets/css/bottom.css" rel="stylesheet">
    <link href="assets/css/video.css" rel="stylesheet">
    <link href="assets\css\video.css" rel="stylesheet">
    <link href="assets/css\bottom.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets\cnopca.css">
    <link rel="stylesheet" type="text/css" href="assets/cnopca.css">
    <link rel="stylesheet" type="text/css" href="css\google.css">
    <link rel="stylesheet" type="text/css" href="css/google.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

    <script type="text/javascript">

        $(function () {
            $(window).scroll(function () {
                if ($(this).scrollTop() != 0) {
                    $('#toTop').fadeIn();
                } else {
                    $('#toTop').fadeOut();
                }
            });
            $('#toTop').click(function () {
                $('body,html').animate({scrollTop: 0}, 800);
            });

        });

    </script>
    <script type="text/javascript">
        $(function () {
            $('#scroll_bottom').click(function () {
                $('html, body').animate({scrollTop: $(document).height() - $(window).height()}, 600);
                return false;
            });
        });
    </script>
</head>