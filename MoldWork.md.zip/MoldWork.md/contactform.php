<?php
require_once "config.sql.php";

if((isset($_POST['submit'])))
{

$Name = $conexiune->real_escape_string($_POST['name']);
$Email = $conexiune->real_escape_string($_POST['email']);
$Phone = $conexiune->real_escape_string($_POST['contact']);
$comments = $conexiune->real_escape_string($_POST['text']);

$sql="INSERT INTO contactele (name, email, phone, comments) VALUES ('".$Name."','".$Email."', '".$Phone."', '".$comments."')";

if(!$result = $conexiune->query($sql)){
die('Eroare: [' . $conexiune->error . ']');
}
else
   echo "tot a fost cu succes";

	mysqli_close($conexiune);
}
header('location: /');
?>