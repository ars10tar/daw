-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 21 2021 г., 10:56
-- Версия сервера: 10.1.48-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `moldwork`
--

-- --------------------------------------------------------

--
-- Структура таблицы `contactele`
--

CREATE TABLE `contactele` (
  `id` int(4) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `domains`
--

CREATE TABLE `domains` (
  `id` int(11) NOT NULL,
  `domain_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `domains`
--

INSERT INTO `domains` (`id`, `domain_name`) VALUES
(1, 'IT'),
(2, 'Banking'),
(3, 'Marketing');

-- --------------------------------------------------------

--
-- Структура таблицы `fteam`
--

CREATE TABLE `fteam` (
  `ID_FTeam` int(11) NOT NULL,
  `TeamName` varchar(255) NOT NULL,
  `TeamMembers` varchar(255) NOT NULL,
  `TeamLogo` varchar(255) NOT NULL,
  `TeamRegion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `fteam`
--

INSERT INTO `fteam` (`ID_FTeam`, `TeamName`, `TeamMembers`, `TeamLogo`, `TeamRegion`) VALUES
(40, 'Programmers', ' 2 3 5', 'Lays-Logo.png', 'AU');

-- --------------------------------------------------------

--
-- Структура таблицы `job2021`
--

CREATE TABLE `job2021` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `data_n` date NOT NULL,
  `an_inscriere` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `telefon` varchar(15) NOT NULL,
  `mobil` varchar(20) NOT NULL,
  `comentariu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `job2021`
--

INSERT INTO `job2021` (`id`, `name`, `data_n`, `an_inscriere`, `email`, `telefon`, `mobil`, `comentariu`) VALUES
(1, 'WebDesigner', '2021-12-15', 2, 'vborjac@mail.ru', '02254254', '06541254', 'Portofoliu de proiecte (cu alte cuvinte, experienИ›Дѓ de lucru).\r\nCunoИ™tinИ›e de bazДѓ de HTML вЂљCSS И™i abilitДѓИ›i de bazДѓ de layout.\r\nCunoИ™tinИ›e Photoshop, Illustrator, CorelDraw, Flash (ocazional alte programe de graficДѓ).\r\nAbilitatea de a crea icoane, ilustraИ›ii И™i bannere.'),
(2, 'rgr', '2021-12-15', 4, 'vborjac@mail.ru', '02254254', '06541254', 'trhrhrt');

-- --------------------------------------------------------

--
-- Структура таблицы `team_data`
--

CREATE TABLE `team_data` (
  `id` int(11) NOT NULL,
  `domain_id` int(11) NOT NULL,
  `team_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_number` int(11) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `team_data`
--

INSERT INTO `team_data` (`id`, `domain_id`, `team_name`, `person_number`, `description`) VALUES
(1, 1, 'PC_Destroyers', 5, 'O echipДѓ de top din RM care a realizat cel mai optimizat И™i funcИ›ional site Web din  toatДѓ reИ›eau globalДѓ Internet'),
(2, 2, 'MAIB', 50, 'testДѓm'),
(3, 3, 'Promotion_team', 3, '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `family` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `team_id` int(5) NOT NULL,
  `localitatea` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `specialitatea` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `despre` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `priecte` text COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `name`, `family`, `password`, `team_id`, `localitatea`, `specialitatea`, `despre`, `priecte`) VALUES
(1, 'mexpert', 'vborjac@mail.ru', 'ivan', 'borjac', '$2y$10$VG6CfFgiyH20AozzCOpNYuMSg0iEdlAXSRvfG97thYhelErNw5qoC', 0, '', '', '', ''),
(2, 'mexpertik', 'vborjac@yandex.ru', 'ivan', 'borjac', '$2y$10$k5jczU8ZZlSwI/7nBpZuquNoGXycI2mAshzDsTxM5Kvdp6hnoj7JW', 40, '', '', '', ''),
(3, 'velarmic', 'vborjac@gmail.com', 'vanea', 'mexpert', '$2y$10$6m/mwbpqWSDjasjjK5aCuOoM7xq47mEyt78gHF2yU0wIDAqfrm9.a', 40, '', '', '', ''),
(5, 'augustina', 'rotari03@gmail.com', 'rotari', 'Augustina', '$2y$10$QhCNBd2vgIVWU8L3iSAxvOHrtDIU8fk5CudV7Bea4PzVu4Bt39bC2', 40, 'Chișinău', 'Graphical designe', 'O specialistă de nivel superior!', 'test, test');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `contactele`
--
ALTER TABLE `contactele`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `fteam`
--
ALTER TABLE `fteam`
  ADD PRIMARY KEY (`ID_FTeam`);

--
-- Индексы таблицы `job2021`
--
ALTER TABLE `job2021`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `team_data`
--
ALTER TABLE `team_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `domain_id` (`domain_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `contactele`
--
ALTER TABLE `contactele`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `domains`
--
ALTER TABLE `domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `fteam`
--
ALTER TABLE `fteam`
  MODIFY `ID_FTeam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT для таблицы `job2021`
--
ALTER TABLE `job2021`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `team_data`
--
ALTER TABLE `team_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `team_data`
--
ALTER TABLE `team_data`
  ADD CONSTRAINT `team_data_ibfk_1` FOREIGN KEY (`domain_id`) REFERENCES `domains` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
